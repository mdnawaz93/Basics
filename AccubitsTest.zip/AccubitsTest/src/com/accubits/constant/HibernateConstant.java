package com.accubits.constant;
public class HibernateConstant {
	
	public static String jdbcDriverClassName="com.mysql.jdbc.Driver";
	public static String jdbcUrl="jdbc:mysql://localhost:3306/accubits";
	public static String jdbcUsername="root";
	public static String jdbcPassword="root";
	
	
	public static String hibernateDialect="org.hibernate.dialect.MySQLDialect";
	public static String hibernateShowSql="true";
	public static String hibernateFormatSql="true";
	public static String hibernate_hbm2ddl_auto="update";
	//public static String jdbcDriverClassName="";

}
