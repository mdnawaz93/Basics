package com.accubits.constant;

public class MessageConstant {

	public static String success = "success";
	public static String fail = "fail";
}
